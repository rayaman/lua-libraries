/**********************************************************
* Copyright (C) 2005, by Jas Latrix (jastejada@yahoo.com) * 
* All Rights Deserved.                                    *
* use this code at your own risk!.                        *
* breast milk is still best for babies.                   *
**********************************************************/
/*!!!<?xml version="1.0" encoding="UTF-8"?>
<module name="DateLua"><description>
	DateLua is a Lua 5.0 binary module for date and time calculatione and retrieval.
	It uses the soucre code (modified) of <link text="JavaScript 1.5" href="http://www.mozilla.org/js"/> Date and Time Functions which is based on Standard ECMA-262. 
</description><description name="Date value">
	A date value is a number between +8640000000000000 and -8640000000000000 that represents milliseconds since midnight 01 January, 1970 UTC (date value = 0, a.k.a. "epoch").
</description><description name="Start">
	Just call 'require("date")' in your Lua script.
	Make sure lua can search 'date.dll' and 'date.lua'.
	This will make a global table called '<link text="date"/>'.
</description><object name="date">!!!*/
/*###</object>
<description name="Licence">
Copyright (C) 2005, by Jas Latrix (jastejada@yahoo.com).
All Rights Deserved.
Use at your own risk!. 
Shake well before using.
</description>
</module>###*/
#define DATE_LIB_NAME "date"
#define DATE_MET_NAME "sysx.date"
/*** LUA ***/
#include "lua.h"
#include "lauxlib.h"
#include "macro_lua.h"
#include <stdlib.h>
/*** TIME AND DATE CALCULATOR ***/
#include "date_ecma.h"
/*** LOCAL TIME GETTER ***/
#include "date_local.h"


char* weekdays[] = {
/*0*/"Sunday","Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday",
/*7*/"Sun","Mon","Tue","Wed","Thu","Fri","Sat",
	NULL
};
#define dc_wday_strl(i)	weekdays[(i)]
#define dc_wday_strs(i)	dc_wday_strl((i)+7)
char* months[] = {
/*01*/"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December",
/*12*/"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
	NULL
};
#define dc_mon_strl(i)	months[i]
#define dc_mon_strs(i)	dc_mon_strl((i)+12)
/*** ADDITIONAL LUA API **/
int luaL_findstringi (const char *name, const char *const list[]) {
	int i;
	for (i=0; list[i]; i++){
		if (strcmpi(list[i], name) == 0)return i;
	}
	return -1;  /* name not found */
}
int luaL_get_num_or_list(lua_State *L, int idx, const char *const list[], int limit, const char * name){
	if(LUA_ISNUM(idx)){
		return LUA_TONUM(idx,int);
	}else if(LUA_ISSTR(idx)){
		const char * pcsz = LUA_TOSTR(idx);
		int i = luaL_findstringi (pcsz, list);
		if(i<0){
			luaL_error(L,"Invalid \"%s\" at arg# %d (\"%s\")",name,idx,pcsz);
		}
		return (i>limit)?(i-limit):i;
	}else{
		luaL_error(L,"Expected \"%s\" string or \"%s\" number",name,name);
		return 0;
	}
}
#define LUA_CHKMONTH(idx,typ)	((typ)luaL_get_num_or_list(L,(int)idx, months, 12, "month"))
#define LUA_CHKWDAY(idx,typ)	((typ)luaL_get_num_or_list(L,(int)idx, weekdays, 7, "weekdays"))

/* Assuming index 1 is the dateval userdata, gets the pointer to it*/
dateval luaL_checkdate(lua_State *L) {
	dateval* pdv = LUA_TOUSR(1,dateval*);
	if(!pdv)luaL_error(L,"Error getting date value");
	/** /TRC("luaL_checkdate %.15g",pdv[0]);/**/
	return pdv[0];
}
dateval *luaL_checkdateP(lua_State *L) {
	dateval* pdv = LUA_TOUSR(1,dateval*);
	if(!pdv)luaL_error(L,"Error getting date value");
	/** /TRC("luaL_checkdateP %.15g",pdv[0]);/**/
	return pdv;
}
dateval luaL_checkdateloc(lua_State *L, int *pbias) {
	dateval* pdv = LUA_TOUSR(1,dateval*);
	dateval dv = 0;
	if(pdv==NULL||lt_utc2loc(*pdv,&dv,pbias)==0){
		luaL_error(L,"Error getting local date value");
	}
	/** /TRC("luaL_checkdateloc %.15g",pdv[0]);/**/
	return dv;
}
dateval *luaL_checkdatelocP(lua_State *L, int *pbias) {
	dateval* pdv = LUA_TOUSR(1,dateval*);
	/** /TRC_DV(*pdv,"luaL_checkdateloc");/**/
	if((pdv==NULL)||lt_utc2loc(pdv[0],pdv,pbias)==0){
		luaL_error(L,"Error getting local date value");
	}
	return pdv;
}



/*** HELPERS ***/
#define ISDATECODEFMT(c)	(c == '%')
#define ISDATECODECHR(c)	(ISALPHA(c))
#define NIL '\0'
#define NUL "\0"
#define LUA_ERR_BADCODE(p)	luaL_error(L,"date code near \"%s...\" is invalid or not supported or not applicable.",p)
#define LUA_ERR_BADDATE()
/**/
typedef struct _KEYCODE {
	const char * Name;/* the code string */
	int Code;/* the code number */
} KEYCODE;
#define KEYITEM(s,c)	{"" s, c},
KEYCODE kc[] = {
#define DTC_MS	('m'*'s')
#define DTC_SC	('s'*'c')
#define DTC_MN	('m'*'n')
#define DTC_HR	('h'*'r')
#define DTC_YR	('y'*'r')
#define DTC_MO	('m'*'o')
#define DTC_MD	('m'*'d')
#define DTC_YD	('y'*'d')
#define DTC_WD	('w'*'d')
#define DTC_DY	('d'*'y')
#define DTC_BI	('b'*'i')
KEYITEM("miliseconds",DTC_MS) KEYITEM("msec",DTC_MS)
KEYITEM("sc",DTC_SC) KEYITEM("seconds",DTC_SC)
KEYITEM("mn",DTC_MN) KEYITEM("minutes",DTC_MN)
KEYITEM("hr",DTC_HR) KEYITEM("hours",DTC_HR)
KEYITEM("months",DTC_MO)
KEYITEM("yr",DTC_YR) KEYITEM("years",DTC_YR)
KEYITEM("wday",DTC_WD)
KEYITEM("mday",DTC_MD)
KEYITEM("yday",DTC_YR)
KEYITEM("dy",DTC_DY) KEYITEM("days",DTC_DY)
KEYITEM("bias",DTC_BI)
/* misc */
{0,0}/* invalid date code */
};
/**/
int dt_cmpcode (const char * sb, const char * sc ){
	while ( sb[0] && sb[0] == sc[0])  {
		sb++;	sc++;
	}
	return(ISDATECODECHR(sb[0]));
}

int dt_getcode(const char ** ppstr){
	KEYCODE* pkc = &kc[0];
	/* skip the unwanted chars */
	while((*ppstr)[0] && !ISDATECODECHR((*ppstr)[0]))(*ppstr)++;
	if(!(*ppstr)[0])return -1;
	/* is it a date code */
	while(pkc->Name && dt_cmpcode(ppstr[0],pkc->Name))pkc++;
	/* skip date code chars */
	while((*ppstr)[0] && ISDATECODECHR((*ppstr)[0]))(*ppstr)++;
	/** /TRC("%s %d %d >%s<",pkc->Name,pkc->Code,len,ppstr[0]);/**/
	return pkc->Code;
}
/*@@@<method name=".parse" args="var_date"><description>
	Parses <arg name="var_date"/> and returns the <link text="dateobject"/> of that date.
</description><description name = "Parsable String">
	if <arg name="var_date"/> is a string then must be format in format like.
	<example>
	Monday, May 02 2005 10:45:23 AM UTC
	Jan 5, 1996 08:47:00
	05/02/05 10:41:36 UTC (comment (comment in comment))</example>
	Commas and spaces are treated as delimiters.
	You can add comment by enclosing them by parenthesis, these parentheses may be nested.
	Use colons as separator for Hours, minutes, and seconds.
	Use "/" or "-" as date separator.
	The format must be month/day/year for short dates e.g "6-12-1983".
	In Long date format year, month, and day can be in any order e.g. "November 15, 2003".
	If you use the 2-digit form, the year must be greater than or equal to 70.
	Standard timezone (GMT, UT, UTC, EST, EDT, CST, CDT, MST, MDT, PST, PDT) are supported.
	There is a special timezone called "LOC", meaning the date string is a local time it will use the local time zone.
</description><description name = "Parsable Table">
	if <arg name="var_date"/> is a table. it will look for this value
	<matrix>
	<R><C C="var_date.year"/><C T="a number, the full year, for example, 1969 (and not 69). (default = 1970)"/></R>
	<R><C C="var_date.month"/><C T="a number, the month as a number from 0 to 11 (January-December). (default = 0)"/></R>
	<R><C C="var_date.day"/><C T="a number, the date as an integer from 1 to 31. (default = 1)"/></R>
	<R><C C="var_date.hour"/><C T="a number, hours value, integer from 0 to 23, indicating the number of hours since midnight. (default = 0)"/></R>
	<R><C C="var_date.min"/><C T="a number, minutes value, integer from 0 to 59. (default = 0)"/></R>
	<R><C C="var_date.sec"/><C T="a number, seconds value, integer from 0 to 59. (default = 0)"/></R>
	<R><C C="var_date.msec"/><C T="a number, miliseconds value, integer from 0 to 59. (default = 0)"/></R>
	<R><C C="var_date.local, var_date.loc"/><C T="a boolean that indicates that this table is a local time. (default = false)"/></R>
	</matrix>
</description><description name = "Parsable Number">
	if <arg name="var_date"/> is a number, it must be a <link text="Date Value"/>.
</description><description name = "Copying dateobject">
	if <arg name="var_date"/> is a <link text="dateobject"/>, a copy of the that <link text="dateobject"/> is returned.
</description><description name = "Current Time">
	if <arg name="var_date"/> is true or no argument given, the <link text="dateobject"/> of the current time is returned.
</description></method>
<method name=".parsel" args="var_date"><description>
	Same as <link text="date.parse"/> except that it defaults to localtime.
	e.g. if the <arg name="var_date"/> is date string "Friday, September 13 2024" that does not include timezone, that date will be parse as a locatime.
</description></method>
@@@*/

dateval date_aux_getarg(lua_State *L, int idx, int *plocal){
#define LT_GET_PLOCAL	plocal
#define LT_GET_LOCAL	*plocal
#define LT_SET_LOCAL(v)	if(plocal)*plocal=(v)
#define LT_USE_UTC		LT_SET_LOCAL(0)
	dateval dv = 0;
	int typ = LUA_TYPE(idx);
	switch(typ){
	/*****/case LUA_TUSERDATA:{
		dv = LUA_CHKUSR(idx,DATE_MET_NAME,dateval*)[0];
		LT_USE_UTC;
	}break;case LUA_TNUMBER:{
		dv = LUA_TONUM(idx,dateval);
	}break;case LUA_TSTRING:{
		const char * pcstr = LUA_CHKLSTR(idx,NULL);
		if(!parseString(pcstr,&dv,LT_GET_PLOCAL)){
			luaL_error(L,"Error Parsing Date \"%s\"",pcstr);
		}
	}break;case LUA_TTABLE:{
		int time = 0;
		int date = 0;
		dateval yr	= 1970;		dateval mo	= 0;		dateval md	= 1;
		dateval hr	= 0;		dateval mn	= 0;		dateval sc	= 0;
		dateval ms	= 0;
		if(LUA_TGETL(idx,"month")||LUA_TGETL(idx,"mon")){
			mo = LUA_CHKMONTH(-1,dateval);date++;
		}
		if(LUA_TGETL(idx,"year")){
			yr = LUA_CHKNUM(-1,dateval);date++;
		}
		if(LUA_TGETL(idx,"day")||LUA_TGETL(idx,"day")){
			md = LUA_CHKNUM(-1,dateval);date++;
		}
		if(LUA_TGETL(idx,"hour")){
			hr = LUA_CHKNUM(-1,dateval);time++;
		}
		if(LUA_TGETL(idx,"min")||LUA_TGETL(idx,"minute")){
			mn = LUA_CHKNUM(-1,dateval);time++;
		}
		if(LUA_TGETL(idx,"sec")||LUA_TGETL(idx,"seconds")){
			sc = LUA_CHKNUM(-1,dateval);time++;
		}
		if(LUA_TGETL(idx,"msec")||LUA_TGETL(idx,"miliseconds")){
			ms = LUA_CHKNUM(-1,dateval);time++;
		}
		if(!time && !date){
			luaL_argerror(L,idx,"incomplete date table");
		}
		/* is there a local indicator */
		if(LUA_TGETL(idx,"local")||LUA_TGETL(idx,"loc")){
			LT_SET_LOCAL(LUA_TOBOOL(-1));
		}
		dv = msecFromDate(yr,mo,md,hr,mn,sc,ms);
	}break;default:
		if(typ==LUA_TNONE || LUA_ISTRUE(idx)){
			lt_now(&dv);
			LT_USE_UTC;
		}else{
			luaL_argerror(L,idx,"expected dateobject or a date number or a date table or a date string");
		}
	}
	return dv;
}
/*@@@<object name="dateobject"><description>
date object is a Lua userdata containing a date value with metamethods.
</description>
<method name=":get" args="str_code"><description>
	return the value(s) of the date according to <arg name="str_code"/> 
</description>@@@*/
/* will push variable argument to the stack */
static int date_aux_get(lua_State *L, const dateval cdv, const char *pcstr, int *pbias){
	int	 r = 0;/* return pushed val */
	const char * pcsz = 0;
	/** /TRC(">%s<",pcstr);/**/
	while(pcstr[0]){
		pcsz = pcstr;
		switch(dt_getcode(&pcstr)){
		/*@@@<matrix>@@@*/
		/****/case -1:goto HELL;/*@@@<R><C T="Return Value " hdr='yes' col="2"/></R>@@@*/
		break;case DTC_MS:LUA_PUSHNUM(dv_msec(cdv));/*@@@<R><C C="msec, ms"/><C T="millisecond value, integer between 0 and 999."/></R>@@@*/
		break;case DTC_SC:LUA_PUSHNUM(dv_sec(cdv));/*@@@<R><C C="sec, sc"/><C T="seconds value, integer between 0 and 59."/></R>@@@*/
		break;case DTC_MN:LUA_PUSHNUM(dv_min(cdv));/*@@@<R><C C="min, mn"/><C T="minutes value, integer between 0 and 59."/></R>@@@*/
		break;case DTC_HR:LUA_PUSHNUM(dv_hour(cdv));/*@@@<R><C C="hour, hr"/><C T="hours value, integer between 0 and 23, indicating the number of hours since midnight"/></R>@@@*/
		break;case DTC_YR:LUA_PUSHNUM(dv_year(cdv));/*@@@<R><C C="year, yr"/><C T="full year value (1981,2536,1521)"/></R>@@@*/
		break;case DTC_MO:LUA_PUSHNUM(dv_month(cdv));/*@@@<R><C C="month, mo"/><C T="month value, integer between 0(january) and 11(december)"/></R>@@@*/
		break;case DTC_MD:LUA_PUSHNUM(dv_mday(cdv));/*@@@<R><C C="mday, md"/><C T="day of month value (date), integer between 1 and 31 that represents the date value "/></R>@@@*/
		break;case DTC_YD:LUA_PUSHNUM(dv_yday(cdv));/*@@@<R><C C="yday, yd"/><C T="day of year value, integer between 0 and 366"/></R>@@@*/
		break;case DTC_WD:LUA_PUSHNUM(dv_wday(cdv));/*@@@<R><C C="wday, wd"/><C T="day of week value, integer between 0 and 6 (0:Sunday,1:Monday - 6:Saturday)"/></R>@@@*/
		break;case DTC_BI:
			if(pbias){
				LUA_PUSHNUM(*pbias);break;
			}/* fall tru --> */
		/*@@@</matrix>@@@*/
		default:
			LUA_ERR_BADCODE(pcsz);
		}/** /TRC(">%s<",pcsz);/**/
		r++;/* if we got here we pushed a value so inc r */
	}
HELL:
	return r;
}
/*@@@<description>
use ','(comma) or ' '(space) as a separator
</description><example>
require'date'
x = date.parse('November 23 1986 12:45:14')
yr,mo,dt = x:get('yr,mo,md')
print(yr .. '/' .. mo .. '/' .. dt) --[[ 1986/10/23 ]]
</example></method>
<method name=":getl" args="str_code"><description>
Same as <link text="dateobject:get"/> except that it uses the equivalent localtime date value of <parentobject/>.
Additional code "bias" or "bi" meaning the bias to utc time of the local time in minutes.
</description><example>
require'date'
x = date.parse('November 23 1986 12:45:14')
yr,mo,md,hr,mn,sc,ms,bi = x:getl('yr,mo,md,hr,mn,sc,ms,bi')
s = string.format("%s-%s-%s %s:%s:%s:%s %s",yr,mo,md,hr,mn,sc,ms,bi)
print(s) --[[1986-10-23 3:45:14:0 -540]]
</example></method>
<method name=":span" args="str_code"><description>
return the time spanned since epoch.
</description>@@@*/
static int date_aux_spn(lua_State *L, const dateval cdv, const char *pcstr){
	int	 r = 0;/* return pushed val */
	const char * pcsz = 0;
	/** /TRC(">%s<",pcstr);/**/
	while(pcstr[0]){
		pcsz = pcstr;
		switch(dt_getcode(&pcstr)){
		/*@@@<matrix>@@@*/
		break;case -1:goto HELL;/*@@@<R><C T="Numeric Return Value (Time Spanned since  midnight 01 January, 1970)" hdr='yes' col="2"/></R>@@@*/
		break;case DTC_MS:LUA_PUSHNUM(dv_span_msec(cdv));/*@@@<R><C C="msec, ms"/><C T="miliseconds since epoch"/></R>@@@*/
		break;case DTC_SC:LUA_PUSHNUM(dv_span_sec(cdv));/*@@@<R><C C="sec, sc"/><C T="seconds since epoch"/></R>@@@*/
		break;case DTC_MN:LUA_PUSHNUM(dv_span_min(cdv));/*@@@<R><C C="min, mn"/><C T="minutes since epoch"/></R>@@@*/
		break;case DTC_HR:LUA_PUSHNUM(dv_span_hour(cdv));/*@@@<R><C C="hour, hr"/><C T="hours since epoch"/></R>@@@*/
		break;case DTC_YR:LUA_PUSHNUM(dv_span_year(cdv));/*@@@<R><C C="year, yr"/><C T="years since epoch (assuming 1 year = 365.2425 days)"/></R>@@@*/
		break;case DTC_MO:LUA_PUSHNUM(dv_span_month(cdv));/*@@@<R><C C="month, mo"/><C T="months since epoch (assuming 1 month = 30.43685 days)"/></R>@@@*/
		break;case DTC_DY:LUA_PUSHNUM(dv_span_day(cdv));/*@@@<R><C C="day, dy"/><C T="days since epoch"/></R>@@@*/
		/*@@@</matrix>@@@*/
		break;default:LUA_ERR_BADCODE(pcsz);
		}
		/** /TRC(">%s<",pcsz);/**/
		r++;/* if we got here we pushed a value so inc r */
	}
HELL:
	return r;
}
/*@@@<description>
use ','(comma) or ' '(space) as a separator
</description><example>
require'date'
d = date.parse("") -- current time
print('it is ' .. d:span('day') .. ' days since 01 January, 1970')
</example></method>@@@*/
/*@@@<method name=":set" args="var_date, str_code, var_1, var_2,...var_n"><description>
returns the adjusted value of var_date according to <arg name="str_code"/> 
</description><description>
use ',', ' '(space), ':', or ';'  as a separator
<matrix><R><C T="Date codes and their equivlent" hdr='yes' col="2"/></R>
<R><C C="msec, ms"/><C T="set the millisecond value, integer between 0 and 999."/></R>
<R><C C="sec, sc"/><C T="set the seconds value, integer between 0 and 59."/></R>
<R><C C="min, mn"/><C T="set the minutes value, integer between 0 and 59."/></R>
<R><C C="hour, hr"/><C T="set the hours value, integer between 0 and 23, indicating the number of hours since midnight."/></R>
<R><C C="year, yr"/><C T="set the full year value (1981,2536,1521)."/></R>
<R><C C="month, mo"/><C T="set the month value, integer between 0(january) and 11(december)."/></R>
<R><C C="mday, md"/><C T="set the day of month value (date), integer between 1 and 31 that represents the date value."/></R>
</matrix></description><example>
-- This will print all friday the 13 dates between yr1 and yr2
function fd13(yr1,yr2)
	dt = date.parse({year=yr1}) -- make a dateobj
	while dt:add('mo',1):get('yr') &lt;= yr2 do
		 -- set the day of the month to 13 check if friday 
		if(dt:set('md',13):get('wd')==5)then
			print(dt:fmt('%B %Y, %A the %dth'))
		end
	end
end
fd13(2000,2666)
</example></method>
<method name=":setl" args="str_code"><description>
Same as <link text="dateobject:set"/> except that it uses the equivalent localtime date value of <parentobject/>.
</description><example>
-- Get the Date of U.S. Labor Day, (the first Monday in September).
-- Get current date
ld = date.parse()
-- Set month to September and date to 0
-- The result date is the last day of August
ld:setl("mo,md","Sep",0)
-- Add a day, check if it is a monday
while(ld:addl('dy',1):getl('wd')~=1)do
	-- Loop until the day is monday
end
print(ld:fmtl('%D'))
</example></method>@@@*/
static void date_aux_set(lua_State *L, dateval *pdv, const char *pcstr, int local){
	dateval yr = dv_year(*pdv);
	dateval mo = dv_month(*pdv);
	dateval md = dv_mday(*pdv);
	dateval hr = dv_hour(*pdv);
	dateval mn = dv_min(*pdv);
	dateval sc = dv_sec(*pdv);
	dateval ms = dv_msec(*pdv);
	int	 r = 2;/* the index. 1 = the date val (userdata), 2 = date codes, 3 = var agr... */
	const char * pcsz = 0;
	while(pcstr[0]){
		pcsz = pcstr;
		++r;/* the index */
		switch(dt_getcode(&pcstr)){
		case -1:goto HELL;
		break;case DTC_MS:ms = LUA_CHKNUM(r,dateval);
		break;case DTC_SC:sc = LUA_CHKNUM(r,dateval);
		break;case DTC_MN:mn = LUA_CHKNUM(r,dateval);
		break;case DTC_HR:hr = LUA_CHKNUM(r,dateval);
		break;case DTC_YR:yr = LUA_CHKNUM(r,dateval);
		break;case DTC_MO:mo = LUA_CHKMONTH(r,dateval);
		break;case DTC_MD:md = LUA_CHKNUM(r,dateval);
		/*DTC_YD,DTC_WD:*/
		break;default:LUA_ERR_BADCODE(pcsz);
		}
	}
HELL:
	*pdv = msecFromDate(yr,mo,md,hr,mn,sc,ms);
	if(TimeClip(pdv) && (local?lt_loc2utc(pdv[0],pdv):1)){
		return;
	}else{
		luaL_error(L,"Result yields an invalid date value <%f>",*pdv);
		return;
	}
}
/*@@@<method name=":add" args="str_code"><description>
add a time value to <parentobject/>.
<matrix><R><C T="Date codes and their equivlent" hdr='yes' col="2"/></R>
<R><C C="msec, ms"/><C T="add millisecond(s)."/></R>
<R><C C="sec, sc"/><C T="add second(s)."/></R>
<R><C C="min, mn"/><C T="add minute(s)."/></R>
<R><C C="hour, hr"/><C T="add hour(s)."/></R>
<R><C C="year, yr"/><C T="add year(s)."/></R>
<R><C C="month, mo"/><C T="add month(s)."/></R>
<R><C C="day, dy"/><C T="add day(s)."/></R>
</matrix>
to subtract a time value pass a negative number.
</description><example>
require'date'
d = date.parse('Jan 5 2045 13:40:50')
d:add('hour',24)
print(d:fmt('%c'))--Friday, January 06 2045 01:40:50 PM
d:add('mo,dy',2,5)
print(d:fmt('%c'))--Saturday, March 11 2045 01:40:50 PM
</example></method>@@@*/
static void date_aux_add(lua_State *L, dateval *pdv, const char *pcstr, int local){
	dateval yr = YearFromTime(*pdv);
	dateval mo = MonthFromTime(*pdv);
	dateval md = DateFromTime(*pdv);
	dateval hr = HourFromTime(*pdv);
	dateval mn = MinFromTime(*pdv);
	dateval sc = SecFromTime(*pdv);
	dateval ms = msFromTime(*pdv);
	int	 r = 2;/* the index. 1 = the date val (userdata), 2 = date codes, 3 = var agr... */
	const char * pcsz = 0;
	while(pcstr[0]){
		pcsz = pcstr;
		++r;/* the index */
		switch(dt_getcode(&pcstr)){
		case -1:goto HELL;
		break;case DTC_MS:ms += LUA_CHKNUM(r,dateval);
		break;case DTC_SC:sc += LUA_CHKNUM(r,dateval);
		break;case DTC_MN:mn += LUA_CHKNUM(r,dateval);
		break;case DTC_HR:hr += LUA_CHKNUM(r,dateval);
		break;case DTC_YR:yr += LUA_CHKNUM(r,dateval);
		break;case DTC_MO:mo += LUA_CHKNUM(r,dateval);
		break;case DTC_DY:md += LUA_CHKNUM(r,dateval);
		/*DTC_YD,DTC_WD:*/
		break;default:LUA_ERR_BADCODE(pcsz);
		}
	}
HELL:
	*pdv = msecFromDate(yr,mo,md,hr,mn,sc,ms);
	if(TimeClip(pdv) && (local?lt_loc2utc(pdv[0],pdv):1)){
		return;
	}else{
		luaL_error(L,"Result yields an invalid date value <%f>",*pdv);
		return;
	}
}
/*@@@<method name=":fmt" args="str_code"><description>
return a formatted text, under the control of the <arg name="str_code"/> format and the values stored in <parentobject/>.
@@@*/
static int date_aux_str(lua_State *L, const dateval cdv, const char * pcsz, const unsigned int flag, const int bias) {
#define FMT_LOCALTIME	4
#define FMT_USELOCALE	8
#define FMT_DEFAULT		16
#define FMT_DST			32
	int yr = YearFromTime(cdv);
	int mo = MonthFromTime(cdv);
	int md = DateFromTime(cdv);
	int hr = HourFromTime(cdv);
	int mn = MinFromTime(cdv);
	int sc = SecFromTime(cdv);
	int ms = msFromTime(cdv);
	int wd = WeekDay(cdv);
	int dy = DayWithinYear(cdv,yr);
	int wx = 0; /*temp*/
	int tx = 0;
	luaL_Buffer buf;
	char chBuf[128] = {0};
	char * pstmp = &chBuf[0];/* ptr to char buffer */
	luaL_buffinit(L, &buf);
	/** /TRC("HR=%d %s %d TM=%.15g ",hr,dc_mon_strl(mo),yr,cdv);//*/
	while(pcsz[0]){
		if(ISDATECODEFMT(pcsz[0])){
			chBuf[0] = 0;
			pstmp = &chBuf[0];/* ptr to char buffer */
			switch((++pcsz)[0]){
/*@@@<matrix>@@@*/
/*@@@<R><C C="%%"/><C T="percent character %."/></R>@@@*/
			case '%':case NIL:pstmp = "%";
/*@@@<R><C C="%a"/><C T="The abbreviated weekday name."/></R>@@@*/
			break;case 'a':
				if(!(FMT_USELOCALE&flag) || !lt_get_day_name(pstmp,128,wd,0)){
					pstmp = dc_wday_strs(wd);
				}
/*@@@<R><C C="%A"/><C T="The full week day name."/></R>@@@*/
			break;case 'A':
				if(!(FMT_USELOCALE&flag) || !lt_get_day_name(pstmp,128,wd,1)){
					pstmp = dc_wday_strl(wd);
				}
/*@@@<R><C C="%b,%h"/><C T="The abbreviated month name."/></R>@@@*/
			break;case 'b':case 'h':
				if(!(FMT_USELOCALE&flag) || !lt_get_month_name(pstmp,128,mo,0)){
					pstmp = dc_mon_strs(mo);
				}
/*@@@<R><C C="%B"/><C T="The full month name."/></R>@@@*/
			break;case 'B':
				if(!(FMT_USELOCALE&flag) || !lt_get_month_name(pstmp,128,mo,1)){
					pstmp = dc_mon_strl(mo);
				}
/*@@@<R><C C="%c"/><C T="date and time."/></R>@@@*/
			break;case 'c':
				if(!(FMT_USELOCALE&flag) || !lt_get_datetime_str(cdv,chBuf,128,'c')){
					sprintf(pstmp,"%s %s %.2d %d %.2d:%.2d:%.2d",dc_wday_strs(wd),dc_mon_strs(mo),md,yr,hr,mn,sc);
				}
/*@@@<R><C C="%C"/><C T="Century (year/100)."/></R>@@@*/
			break;case 'C':itoa(yr/100,pstmp,10);
/*@@@<R><C C="%d"/><C T="The day of the month as a decimal number (range 01 to 31)."/></R>@@@*/
			break;case 'd':sprintf(pstmp,"%.2d",md);
/*@@@<R><C C="%D"/><C T="Month/day/year from 01/01/00 (12/02/79)."/></R>@@@*/
			break;case 'D':sprintf(pstmp,"%.2d/%.2d/%.2d",mo+1,md,yr%100);
/*@@@<R><C C="%e"/><C T="day of the month, leading space for zero ( 2)."/></R>@@@*/
			break;case 'e':sprintf(pstmp,"%2d",md);
/*@@@<R><C C="%F"/><C T="year-month-day (1979-12-02)."/></R>@@@*/
			break;case 'F':sprintf(pstmp,"%.4d-%.2d-%.2d",yr,mo+1,md);
/*@@@<R><C C="%H"/><C T="The hour as a decimal number using a 24-hourclock (range 00 to 23)."/></R>@@@*/
			break;case 'H':sprintf(pstmp,"%.2d",hr);
/*@@@<R><C C="%I"/><C T="The hour as a decimal number using a 12-hour clock (range 01 to 12)."/></R>@@@*/
			break;case 'I':sprintf(pstmp,"%.2d",dc_12hr(hr));
/*@@@<R><C C="%j"/><C T="The day of the year as a decimal number (range 001 to 366)."/></R>@@@*/
			break;case 'j':sprintf(pstmp,"%.3d",dy);
/*@@@<R><C C="%K"/><C T="miliseconds 000-999*"/></R>@@@*/
			break;case 'K':sprintf(pstmp,"%.3d",ms);
/*@@@<R><C C="%m"/><C T="The month as a decimal number (range 01 to 12)."/></R>@@@*/
			break;case 'm':sprintf(pstmp,"%.2d",mo+1);
/*@@@<R><C C="%M"/><C T="The minute as a decimal number."/></R>@@@*/
			break;case 'M':sprintf(pstmp,"%.2d",mn);
/*@@@<R><C C="%p"/><C T="Either`AM' or `PM' according to the given time value."/></R>@@@*/
			break;case 'p':pstmp = dc_xmeridian(hr);
/*@@@<R><C C="%r"/><C T="12-hour time, from 01:00:00 AM (06:55:15 AM)."/></R>@@@*/
			break;case 'r':sprintf(pstmp,"%.2d:%.2d:%.2d %s",dc_12hr(hr),mn,sc,dc_xmeridian(hr));
/*@@@<R><C C="%R"/><C T="hour:minute, from 01:00 (06:55)"/></R>@@@*/
			break;case 'R':sprintf(pstmp,"%.2d:%.2d:%.2d",dc_12hr(hr),mn,sc);
/*@@@<R><C C="%S"/><C T="The second as a decimal number."/></R>@@@*/
			break;case 'S':sprintf(pstmp,"%.2d",sc);
/*@@@<R><C C="%T"/><C T=" 24-hour time, from 00:00:00 (06:55:15)"/></R>@@@*/
			break;case 'T':sprintf(pstmp,"%.2d:%.2d:%.2d",hr,mn,sc);
/*@@@<R><C C="%u"/><C T="ISO 8601 day of the week, to 7 for Sunday (7)"/></R>@@@*/
			break;case('u'):itoa(wd==0?7:wd,pstmp,10);
/*@@@<R><C C="%U"/><C T="Sunday week of the year, from 00 (48)"/></R>@@@*/
			break;case('U'):
				wx = wd;
				goto weeknum;   /* join common code */
/*@@@<R><C C="%W"/><C T="Monday week of the year, from 00 (48)"/></R>@@@*/
			break;case('W'):
				wx = (wd == 0)?6:(wd - 1); /* monday based */
			weeknum:
				if(dy < wx){
					tx = 0;
				}else{
					tx = dy/7;
					if((dy%7) >= wx)tx++;
				}
				sprintf(pstmp,"%.2d",tx);
/*@@@<R><C C="%w"/><C T="The day of the week as a decimal, Sunday being 0."/></R>@@@*/
			break;case 'w':itoa(wd,pstmp,10);
/*@@@<R><C C="%Y"/><C T="year of the century, from 00 (79)."/></R>@@@*/
			break;case 'y':sprintf(pstmp,"%.2d",yr%100);
/*@@@<R><C C="%Y"/><C T="The full year as a decimal number."/></R>@@@*/
			break;case 'Y':itoa(yr,pstmp,10);
/*@@@<R><C C="%x"/><C T="date."/></R>@@@*/
			break;case 'x':
				if(!(FMT_USELOCALE&flag) || !lt_get_datetime_str(cdv,chBuf,128,'x')){
					sprintf(pstmp,"%s %s %.2d %d",dc_wday_strs(wd),dc_mon_strs(mo),md,yr);
				}
/*@@@<R><C C="%X"/><C T="time."/></R>@@@*/
			break;case 'X':;
				if(!(FMT_USELOCALE&flag) || !lt_get_datetime_str(cdv,chBuf,128,'X')){
					sprintf(pstmp,"%.2d:%.2d:%.2d",hr,mn,sc);
				}
/*@@@<R><C C="%z"/><C T="Time zone (hours east*100 + minutes), if any (-0500)."/></R>@@@*/
			break;case 'z':
				if(FMT_LOCALTIME&flag){
					sprintf(pstmp,"%+.4d", dc_min_to_100hr(bias));
				}
/*@@@<R><C C="%Z"/><C T="time zone name, if any (EST)."/></R>@@@*/
			break;case 'Z':
				if(FMT_LOCALTIME&flag){
					dateval dutc = cdv - dc_min_to_msec(bias);
					lt_tzstr(dutc,pstmp,128);
				}else{
					pstmp = "UTC";
				}
			break;default:LUA_ERR_BADCODE(pcsz);
/*@@@</matrix>@@@*/
			}
			pcsz++;
			luaL_addstring(&buf,pstmp);
			continue;
		}
		luaL_putchar(&buf,(pcsz++)[0]);
	}
	luaL_pushresult(&buf);
	return 1;
}
/*@@@
</description><example>
require'date'
ld = date.parse("Ju 13 2666 4:59:06")
print(ld:fmt([[
MM/DD/YY:	"%D" "%m/%d/%y"
YYY-MM-DD:	"%F" "%Y-%m-%d"
24hr Time:	"%T" "%H:%M:%S"
12hr Time:	"%r" "%I:%M:%S %p"
Date Time:	"%c" "%x %X"
Date Time:	"%A %B %d %Y %T"
Date Time:	"%a %b %d %Y %r %Z"
]]))
</example></method>
<method name=":fmtl" args="str_code"><description>
Same as <link text="dateobject:fmt"/> except that it uses the equivalent localtime date value of <parentobject/>.
</description><example>
require'date'
ld = date.parse()
print(ld:fmtl([[
Today is %A, %B %d year %Y.
It is the %W week of the year.
It has been %j day(s) since Jan 1 %Y.
We are now on %Cth century.
The time is %r, %T Military time. 
The TimeZone is "%Z" that is GMT%z.
]]))
</example></method>
<method name=":isdst" args=""><description>
returns true if <parentobject/> is covered by Day Ligth Savings Time.
return false if it is not.
returns nil if it cant determine.
</description><example>
require'date'
dsts = nil 
dste = nil
-- get the current time
x = date.parse();
-- set the time to the first day of the current year
x:setl('mo,md,hr,mn,sc,ms',0,1,0,0,0,0)
-- get the current year
year = x:getl('yr')
-- loop until time is in dst
while
	x:add('hr',1):isdst() == false
	and
	year == x:get('yr')  
do end
if(x:isdst())then -- the system time implements dst
	dsts = x:fmtl()
	while -- loop until time is not in dst
		x:add('hr',1):isdst() == true
		and
		year == x:get('yr')  
	do	end
	dste = x:fmtl()
	print(string.format("dst start:\n\t%s\ndst end:\n\t%s",dsts,dste))
end
</example></method>@@@*/
/*@@@</object>@@@*/

void lua_newdv(lua_State *L, dateval dv, int local){
	dateval* pdv = 0;
	/** /TRC_DV(dv,"lua_newdv1");//*/
	if(	TimeClip(&dv)/* in time range ?* / && TRC("<TC %.15g",dv)/**/
	&&	(local?lt_loc2utc(dv,&dv):1)/* if local convert to utc, ok? * / && TRC("<LC %.15g",dv)/**/
	&&	(pdv = LUA_NEWUSR(dateval*, sizeof(dateval)))!=0 /*dateval and bias */
	){	*pdv = dv;
	/** /TRC_DV(dv,"lua_newdv2");//*/
		luaL_getmetatable(L,DATE_MET_NAME);
		lua_setmetatable(L, -2);
	}else{
		luaL_error(L,"Error while creating %sdate value",local?"local ":"");
	}
	return;
}

static int date_aux_parse(lua_State *L, int local){
	dateval dv = date_aux_getarg(L,1,&local);
	lua_newdv(L,dv,local);
	return 1;
}
/*
** UTC TIME FUNCTIONS 
*/
const char cstr_def_get[] = "ms";
static int date_utc_set(lua_State *L) {
	date_aux_set(L,luaL_checkdateP(L),LUA_CHKLSTR(2,NULL),0);
	LUA_PUSHVAL(1);
	return 1;
}
static int date_utc_add(lua_State *L) {
	date_aux_add(L,luaL_checkdateP(L),LUA_CHKLSTR(2,NULL),0);
	LUA_PUSHVAL(1);
	return 1;
}
static int date_utc_get(lua_State *L) {
	return date_aux_get(L,luaL_checkdate(L),LUA_OPTLSTR(2,cstr_def_get,NULL),NULL);
}
static int date_utc_spn(lua_State *L) {
	return date_aux_spn(L,luaL_checkdate(L),LUA_OPTLSTR(2,cstr_def_get,NULL));
}
static int date_utc_str(lua_State *L) {
	int locale = 0;
	const char * pcsz = "%c UTC";
	switch(LUA_TYPE(2)){
	break;case LUA_TNONE:/*dateobj:fmt() use def str*/
	break;case LUA_TBOOLEAN:locale = LUA_TOBOOL(2);/*dateobj:fmt(true|false)  use def str*/
	break;default:/*dateobj:fmt(str_code,bool_uselocale) get str*/
		pcsz = LUA_CHKSTR(2);
		locale = LUA_TOBOOL(3);
	}
	return date_aux_str(L,luaL_checkdate(L),pcsz,locale?FMT_USELOCALE:0,0);
}
/*
** LOCAL TIME FUNCTIONS
*/
static int date_loc_str(lua_State *L) {
	int locale = 0;
	const char * pcsz = "%c UTC%z (%Z)";
	int bias = 0;
	dateval dv = luaL_checkdateloc(L,&bias);
	switch(LUA_TYPE(2)){
	break;case LUA_TNONE:
	break;case LUA_TBOOLEAN:locale = LUA_TOBOOL(2);
	break;default:
		pcsz = LUA_CHKSTR(2);
		locale = LUA_TOBOOL(3);
	}
	return date_aux_str(L,dv,pcsz,(locale?FMT_USELOCALE:0)|FMT_LOCALTIME,bias);
}
static int date_loc_set(lua_State *L) {
	date_aux_set(L,luaL_checkdatelocP(L,NULL),LUA_CHKLSTR(2,NULL),1);
	LUA_PUSHVAL(1);
	return 1;
}
static int date_loc_add(lua_State *L) {
	date_aux_add(L,luaL_checkdatelocP(L,NULL),LUA_CHKLSTR(2,NULL),1);
	LUA_PUSHVAL(1);
	return 1;
}
static int date_loc_get(lua_State *L) {
	int bias = 0;
	return date_aux_get(L,luaL_checkdateloc(L,&bias),LUA_OPTSTR(2,cstr_def_get),&bias);
}
static int date_loc_spn(lua_State *L) {
	return date_aux_spn(L,luaL_checkdateloc(L,NULL),LUA_OPTSTR(2,cstr_def_get));
}
static int date_loc_isdst(lua_State *L) {
	int ret = lt_isdst(luaL_checkdate(L));
	if(ret < 0){LUA_PUSHNIL;
	}else{		LUA_PUSHBOOL(ret);
	}
	return 1;
}
/***/
static const luaL_reg lib_date[] = {
  {"set"	,date_utc_set}, {"setl"	,date_loc_set},
  {"get"	,date_utc_get}, {"getl"	,date_loc_get},
  {"add"	,date_utc_add}, {"addl"	,date_loc_add},
  {"spn"	,date_utc_spn}, {"spnl"	,date_loc_spn},
  {"fmt"	,date_utc_str}, {"fmtl"	,date_loc_str},
  {"span"	,date_utc_spn}, {"spanl",date_loc_spn},
  {"isdst"	,date_loc_isdst},
  {"__tostring", date_utc_str},
  {0,0}
};
/** create a new date value **/

static int date_utc_parse(lua_State *L){
	return date_aux_parse(L,0);
}
static int date_loc_parse(lua_State *L){
	return date_aux_parse(L,1);
}
/*@@@<method name=".diff" args="var_date1, var_date2"><description>
Subtract the <link text="Date Value"/> of <arg name="var_date2"/> to the <link text="Date Value"/> of <arg name="var_date1"/>.
and returns the <link text="dateobject"/> of the result <link text="Date Value"/>.
</description><description>
<arg name="var_date2"/> and <arg name="var_date1"/> must be a <link text="dateobject"/> or parsable date value see <link text="date.parse"/> method.
</description><example>
-- find number of days between 2 dates
d1 = "July 4 1985"
d2 = {month="Nov",mday=1,year=1985}
df = date.diff(d2,d1)
print("There are " .. df:span('days') .. " day(s) between " 
.. date.parse(d1):fmt("%B %d %Y") .. " and " .. date.parse(d2):fmt("%B %d %Y"))
-- This will print the age of the person DATE DIFF
now = date.parse() --[[ time now ]]
bin = date.parsel('sep 12 1981') --[[ your birth day ]]
age = date.diff(now,bin) --[[ get thier difference ]]
old = math.floor(age:span('yr')) --[[ get how much year the date value has (year since epoch) ]]
print(string.format("your are %d years old",old)) --[[ e.g. ]]
</example></method>@@@*/
static int date_diff(lua_State *L){
	dateval dv1 = date_aux_getarg(L,1,0);
	dateval dv2 = date_aux_getarg(L,2,0);
	lua_newdv(L,(dv1 - dv2),0);
	return 1;
}
/*@@@<method name=".isleapyear" args="var_year"><description>
Returns true if <arg name="var_year"/> is a leap year, false if not.
<arg name="var_year"/> must be a full year number or a parsable date value see <link text="date.parse"/> method.
</description><example>
-- print all leap year inbetween this two year
for i=1696, 2696 do
	if date.isleapyear(i) then
		print(i)
	end
end
</example></method>@@@*/
static int date_isleapyear(lua_State *L){
	int year
		=(LUA_ISNUM(1))
		?(LUA_TONUM(1,int))
		:(dv_year(date_aux_getarg(L,1,0)));
	LUA_PUSHBOOL(dc_is_leap_year(year));
	return 1;
}
static const luaL_reg lib_mdate[] = {
  {"parse"	,date_utc_parse},
  {"diff"	,date_diff},
  {"parsel"	,date_loc_parse},
  {"isleapyear"	,date_isleapyear},
  {0,0}
};
int luaopen_date(lua_State *L){
	luaL_newmetatable(L, DATE_MET_NAME);
	luaL_openlib(L, NULL, lib_date, 0);
	LUA_TSETLV("__index",-2);
	LUA_TSETLV("__metatable",-2);
	luaL_openlib(L, DATE_LIB_NAME, lib_mdate, 0);
	return 1;
}
