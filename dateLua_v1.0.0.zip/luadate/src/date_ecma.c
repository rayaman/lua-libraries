/**********************************************************
* Copyright (C) 2005, by Jas Latrix (jastejada@yahoo.com) * 
* All Rights Deserved.                                    *
* use this code at your own risk!.                        *
* cigarette smoking is dangerous to your health.          *
**********************************************************/
#include "date_ecma.h"
dateval TimeWithinDay(dateval t){
    dateval result;
    result = fmod(t, msPerDay);
    if (result < 0)
	result += msPerDay;
    return result;
}

int YearFromTime(dateval t){
    int y = (int) floor(t /(msPerDay*365.2425)) + 1970;
    dateval t2 = (dateval) TimeFromYear(y);

    if (t2 > t) {
        y--;
    } else {
        if (t2 + msPerDay * DaysInYear(y) <= t)
            y++;
    }
    return y;
}

int MonthFromTime(dateval t){
    int d, step;
    int year = YearFromTime(t);
    d = DayWithinYear(t, year);
    if (d < (step = 31))	return 0; step += (InLeapYear(t) ? 29 : 28);
    if (d < step)			return 1;
    if (d < (step += 31))	return 2;
    if (d < (step += 30))	return 3;
    if (d < (step += 31))	return 4;
    if (d < (step += 30))	return 5;
    if (d < (step += 31))	return 6;
    if (d < (step += 31))	return 7;
    if (d < (step += 30))	return 8;
    if (d < (step += 31))	return 9;
    if (d < (step += 30))	return 10;
    return 11;
}

int DateFromTime(dateval t){
    int d, step, next;
    int year = YearFromTime(t);
    d = DayWithinYear(t, year);
    if (d <= (next = 30))	return d + 1;	    step = next;
    if (d <= (next += (InLeapYear(t) ? 29 : 28)))
							return d - step;    step = next;
    if (d <= (next += 31))	return d - step;    step = next;
    if (d <= (next += 30))	return d - step;    step = next;
    if (d <= (next += 31))	return d - step;    step = next;
    if (d <= (next += 30))	return d - step;    step = next;
    if (d <= (next += 31))	return d - step;    step = next;
    if (d <= (next += 31))	return d - step;    step = next;
    if (d <= (next += 30))	return d - step;    step = next;
    if (d <= (next += 31))	return d - step;    step = next;
    if (d <= (next += 30))	return d - step;    step = next;
    return d - step;
}

int WeekDay(dateval t)
{
    int result;
    result = (int) Day(t) + 4;
    result = result % 7;
    if (result < 0)
	result += 7;
    return (int) result;
}
int HourFromTime(dateval t){
    int result = (int) fmod(floor(t/msPerHour), HoursPerDay);
    if (result < 0)
	result += (int)HoursPerDay;
    return result;
}
int MinFromTime(dateval t){
    int result = (int) fmod(floor(t / msPerMinute), MinutesPerHour);
    if (result < 0)	result += (int)MinutesPerHour;
    return result;
}
int SecFromTime(dateval t){
    int result = (int) fmod(floor(t / msPerSecond), SecondsPerMinute);
    if (result < 0)	result += (int)SecondsPerMinute;
    return result;
}
int msFromTime(dateval t){
    int result = (int) fmod(t, msPerSecond);
    if (result < 0)	result += (int)msPerSecond;
    return result;
}
const dateval firstDayOfMonth[2][12] = {
    {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334},
    {0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335}
};
#define DayFromMonth(m, leap) firstDayOfMonth[leap][(int)m];
dateval MakeDay(dateval year, dateval month, dateval date){
    dateval result;
    int leap;
    dateval yearday;
    dateval monthday;

    year += floor(month / 12);

    month = fmod(month, 12.0);
    if (month < 0)
	month += 12;

    leap = (DaysInYear((int) year) == 366);

    yearday = floor(TimeFromYear(year) / msPerDay);
    monthday = DayFromMonth(month, leap);

    result = yearday
	     + monthday
	     + date - 1;
    return result;
}

dateval Float2Int(dateval d){
	int	neg = (d < 0);
    if (d == 0)
	return d;
	d = floor(neg?-d:d);
	return neg ? -d : d;
}
int TimeClip(dateval* pd){
	if(IN_TIME_RANGE(*pd)){
		*pd = Float2Int(*pd+(+0.));
		return 1;
	}else{
		return 0;
	}
}

dateval msecFromDate(dateval year, dateval mon, dateval mday, dateval hour,
		  dateval min, dateval sec, dateval msec)
{
    dateval day;
    dateval msec_time;
    dateval result;
    day = MakeDay(year, mon, mday);
    msec_time = MakeTime(hour, min, sec, msec);
    result = MakeDate(day, msec_time);
    return result;
}


/* for use by date_parse */

static const char* wtb[] = {
/*00*/"am", "pm",
/*02*/"monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
/*09*/"january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december",
/*21*/"gmt", "ut", "utc",
/*24*/"est", "edt",
/*26*/"cst", "cdt",
/*28*/"mst", "mdt",
/*30*/"pst", "pdt"
/*32*/,"loc"/*added*/
/* time zone table needs to be expanded */
};

static int ttb[] = {
    -1, -2, 0, 0, 0, 0, 0, 0, 0,       /* AM/PM */
    2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
    10000 + 0, 10000 + 0, 10000 + 0,   /* GMT/UT/UTC */
    10000 + 5 * 60, 10000 + 4 * 60,    /* EST/EDT */
    10000 + 6 * 60, 10000 + 5 * 60,    /* CST/CDT */
    10000 + 7 * 60, 10000 + 6 * 60,    /* MST/MDT */
    10000 + 8 * 60, 10000 + 7 * 60     /* PST/PDT */
/*added*/,10000-1/**/
};

/* helper for date_parse */
int
regionMatches(const char* s1, int s1off, const char* s2, int s2off,
		   int count, int ignoreCase)
{
    int result = 0;
    /* return true if matches, otherwise, false */

    while (count > 0 && s1[s1off] && s2[s2off]) {
		if (ignoreCase) {
			if (TOLOWER((char)s1[s1off]) != TOLOWER(s2[s2off])) {
				break;
			}
		} else {
			if ((char)s1[s1off] != s2[s2off]) {
				break;
			}
		}
		s1off++;
		s2off++;
		count--;
    }

    if (count == 0) {
	result = 1;
    }

    return result;
}

int
parseString(const char *s, dateval *result, int *plocal)
{
    dateval msec = 0;


    size_t limit = strlen(s);
    size_t i = 0;
    int year = -1;
    int mon = -1;
    int mday = -1;
    int hour = -1;
    int min = -1;
    int sec = -1;
    int c = -1;
    int n = -1;
    dateval tzoffset = -1;  /* was an int, overflowed on win16!!! */
    int prevc = 0;
    int seenplusminus = 0;

    if (limit == 0)
	goto syntax;
	while (i < limit){
		c = s[i];
		i++;
		if (c <= ' ' || c == ',' || c == '-'){
			if (c == '-' && '0' <= s[i] && s[i] <= '9'){
				prevc = c;
			}
			continue;
		}
		if (c == '('){ /* comments) */
			int depth = 1;
			while (i < limit){
				c = s[i];
				i++;
				if (c == '(') depth++;
				else if (c == ')')
					if (--depth <= 0)
						break;
			}
			continue;
		}
		if ('0' <= c && c <= '9'){
			n = c - '0';
			while (i < limit && '0' <= (c = s[i]) && c <= '9'){
				n = n * 10 + c - '0';
				i++;
			}

			/* allow TZA before the year, so
			* 'Wed Nov 05 21:49:11 GMT-0800 1997'
			* works */

			/* uses of seenplusminus allow : in TZA, so Java
			* no-timezone style of GMT+4:30 works
			*/

			if ((prevc == '+' || prevc == '-')/* && year>=0 */){
				/* make ':' case below change tzoffset */
				seenplusminus = 1;

				/* offset */
				if (n < 24)
					n = n * 60; /* EG. "GMT-3" */
				else
					n = n % 100 + n / 100 * 60; /* eg "GMT-0430" */
				if (prevc == '+') /* plus means east of GMT */
					n = -n;
				if (tzoffset != 0 && tzoffset != -1)
					goto syntax;
				tzoffset = n;
			}else if (n >= 70 ||(prevc == '/' && mon >= 0 && mday >= 0 && year < 0)){
				if (year >= 0)
					goto syntax;
				else if (c <= ' ' || c == ',' || c == '/' || i >= limit)
					year = n < 100 ? n + 1900 : n;
				else
					goto syntax;
			}else if (c == ':'){
				if (hour < 0) hour = /*byte*/ n;
				else if (min < 0) min = /*byte*/ n;
				else goto syntax;
			}else if (c == '/'){
				if (mon < 0) mon = /*byte*/ n-1;
				else if (mday < 0) mday = /*byte*/ n;
				else goto syntax;
			}else if (i < limit && c != ',' && c > ' ' && c != '-'){
				goto syntax;
			}else if (seenplusminus && n < 60){ /* handle GMT-3:30 */
				if (tzoffset < 0) tzoffset -= n;
				else tzoffset += n;
			}else if (hour >= 0 && min < 0){
				min = /*byte*/ n;
			}else if (min >= 0 && sec < 0){
				sec = /*byte*/ n;
			}else if (mday < 0){
				mday = /*byte*/ n;
			}else{
				goto syntax;
			}
			prevc = 0;
		}else if (c == '/' || c == ':' || c == '+' || c == '-'){
			prevc = c;
		}else{
			size_t st = i - 1;
			int k;
			while (i < limit){
				c = s[i];
				if (!(('A' <= c && c <= 'Z') || ('a' <= c && c <= 'z')))
					break;
				i++;
			}
			if (i <= st + 1)
				goto syntax;
			for (k = (sizeof(wtb)/sizeof(char*)); --k >= 0;)
				if (regionMatches(wtb[k], 0, s, (int)st, (int)(i-st), 1)){
					int action = ttb[k];
					if (action != 0){
						if (action < 0){
							/*
							* AM/PM. Count 12:30 AM as 00:30, 12:30 PM as
							* 12:30, instead of blindly adding 12 if PM.
							*/
							
							if (hour > 12 || hour < 0){
								goto syntax;
							}else{
								if (action == -1 && hour == 12){ /* am */
									hour = 0;
								}else if (action == -2 && hour != 12){ /* pm */
									hour += 12;
								}
							}
						}else if (action <= 13){ /* month! */
							if (mon < 0){
								mon = /*byte*/ (action - 2);
							}else{
								goto syntax;
							}
						}else if (action == (10000-1)){ /* added local time! */
							*plocal = 1;
						}else{
							tzoffset = action - 10000;
						}
					}
					break;
				}
				if (k < 0)
					goto syntax;
				prevc = 0;
		}
	}
    if (year < 0 || mon < 0 || mday < 0)	goto syntax;
    if (sec < 0)	sec = 0;
    if (min < 0)	min = 0;
    if (hour < 0)	hour = 0;
	/** /TRC("%d-%d-%d %d:%d:%d",year, mon, mday, hour, min, sec);//*/
    msec = msecFromDate(year, mon, mday, hour, min, sec, 0);
    if (tzoffset != -1 && tzoffset != 0) { /* timezone found */
		/** /TRC("%d",tzoffset);//*/
		msec += tzoffset * msPerMinute;
		*plocal = 0;
	}
    *result = msec;
	return 1;

syntax:
    /* syntax error */
    *result = 0;
    return 0;
}