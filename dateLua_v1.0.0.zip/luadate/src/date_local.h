/**********************************************************
* Copyright (C) 2005, by Jas Latrix (jastejada@yahoo.com) * 
* All Rights Deserved.                                    *
* use this code at your own risk!.                        *
* keep out of reach of children.                          *
**********************************************************/
#ifndef __LOCAL_DATE_AND_TIME_H__
#define __LOCAL_DATE_AND_TIME_H__
/*** LOCAL TIME AND DATE (SYSTEM DEPENDENT) ***/
/*
 NOTE:
	All function return 1 on success , 0 on failure
	PARAM	DESCRITION
	dutc	UTC dateval 
	dloc	Local Time dateval
	pdutc	pointer to UTC dateval 
	pdloc	pointer to Local Time dateval
	pdv		pointer to dateval UTC or Local Time
	dv		dateval UTC or Local Time
*/

/*** get the current time **/
int lt_now(dateval * pdv);
/*** get time zone string ***/
int lt_tzstr(dateval dloc, char * pchbuf, size_t szbuf);
/*** convert utc time to local time***/
int lt_utc2loc (const dateval dutc, dateval* pdloc, int * pbias);
/*** convert local time to utc time ***/
int lt_loc2utc (const dateval dloc, dateval* pdutc);
/*** check if time is in dst **/
int lt_isdst(const dateval dutc);
/*** get locale date and time representation ***/
int lt_get_datetime_str(dateval dv, char *pszBuffer, size_t max, int code);
/*** get locale month name ***/
int lt_get_month_name(char *pszBuffer, size_t max, int idx, int abbv);
/*** get locale day name ***/
int lt_get_day_name(char *pszBuffer, size_t max, int idx, int abbv);

/*** USED ONLY FOR TRACING ***/
int TRC(char *pszfmt, ...);
#define TRC_DV(dvx,txt) TRC(txt " %d/%d/%d %d:%d:%d:%d (%.15g)", \
		dv_month(dvx)+1,dv_mday(dvx),dv_year(dvx), \
		dv_hour(dvx),dv_min(dvx),dv_sec(dvx),dv_msec(dvx),dv_span_msec(dvx) \
		)
#define TRC_DV2(dvx,dv2,txt) TRC(txt " %d/%d/%d %d:%d:%d:%d (%.15g)\n%d/%d/%d %d:%d:%d:%d (%.15g)", \
		dv_month(dvx)+1,dv_mday(dvx),dv_year(dvx), \
		dv_hour(dvx),dv_min(dvx),dv_sec(dvx),dv_msec(dvx),dv_span_msec(dvx), \
		dv_month(dv2)+1,dv_mday(dv2),dv_year(dv2), \
		dv_hour(dv2),dv_min(dv2),dv_sec(dv2),dv_msec(dv2),dv_span_msec(dv2) \
		)
#define TRC_TM(ptm,txt) TRC(txt " %d/%d/%d %d:%d:%d %s", \
		ptm.tm_mon+1,ptm.tm_mday,ptm.tm_year, \
		ptm.tm_hour,ptm.tm_min,ptm.tm_sec,ptm.tm_isdst>0?"DST":(ptm.tm_isdst<0?"DST???":"") \
		)

/***/
#endif /*__LOCAL_DATE_AND_TIME_H__*/


