require"dllimport"
-- dllimport lib test
-- print the files in the current folder
-- TODO: Explain everything!

--[[
typedef struct _WIN32_FIND_DATAA { // wfd  
    DWORD dwFileAttributes; 
    FILETIME ftCreationTime; 
    FILETIME ftLastAccessTime; 
    FILETIME ftLastWriteTime; 
    DWORD    nFileSizeHigh; 
    DWORD    nFileSizeLow; 
    DWORD    dwReserved0; 
    DWORD    dwReserved1; 
    CHAR    cFileName[ MAX_PATH ]; 
    CHAR    cAlternateFileName[ 14 ]; 
} WIN32_FIND_DATAA;]]
PROTO_WIN32_FIND_DATA = "L2L2L2LLLLL260S14S"

-- Function Prototype : DWORD GetLastError(VOID);
-- DllImport Prototype: L
GetLastError = dllimport("KERNEL32","GetLastError","L")

-- Function Prototype : VOID SetLastError(DWORD);
-- DllImport Prototype: L
SetLastError = dllimport("KERNEL32","SetLastError","v=L")

-- Function Prototype : FindFirstFile(LPCTSTR, LPWIN32_FIND_DATA);
-- DllImport Prototype: P=pp
FindFirstFile = dllimport("KERNEL32","FindFirstFileA","P=pp")

-- Function Prototype : BOOL FindClose(HANDLE);
-- DllImport Prototype: i=P
FindClose = dllimport("KERNEL32","FindClose","i=p")

-- Function Prototype : BOOL FindNextFile(HANDLE, LPWIN32_FIND_DATA);
-- DllImport Prototype: i=PP
FindNextFile = dllimport("KERNEL32","FindNextFile","i=PP")

-- Function Prototype : BOOL FileTimeToSystemTime(CONST FILETIME, LPSYSTEMTIME);
-- DllImport Prototype: i=PP
FileTimeToSystemTime = dllimport("KERNEL32","FileTimeToSystemTime","i=PP")

-- Function Prototype : BOOL FileTimeToLocalFileTime(CONST FILETIME *,LPFILETIME);
-- DllImport Prototype: i=PP
FileTimeToLocalFileTime = dllimport("KERNEL32","FileTimeToLocalFileTime","i=PP")

local wfd, hnd, err, tt, ft, st, x;
local FILE_ATTRIBUTE_DIRECTORY = tonumber("0000010",16)


wfd = dllimport.pack(PROTO_WIN32_FIND_DATA)
st = dllimport.pack("8H")
ft = dllimport.pack("LL")

SetLastError(0)
hnd = FindFirstFile("*.*", wfd);
err = GetLastError()

if err ~= 0 then
	error("APi Error:"..err)
end

repeat
	-- Get Attributes  from  dwFileAttributes of WIN32_FIND_DATA
	tt = wfd:unpack("L")
	if math.mod(tt/FILE_ATTRIBUTE_DIRECTORY,2) == 1 then
		x = " Directory"
	else
		-- Get size from  nFileSizeHigh and nFileSizeLow of WIN32_FIND_DATA
		tt = {wfd:unpack("28xLL")}
		x = string.format("%10d", tt[2] + tt[1]*(2^32))
	end
	
	-- Get the time from ftLastWriteTime of WIN32_FIND_DATA
	FileTimeToLocalFileTime(wfd:unpack("4x8x8x8s"), ft)
	FileTimeToSystemTime(ft, st)
	tt = {st:unpack()}

	-- Print
	print(string.format("%0.4d-%0.2d-%0.2d %0.2d:%0.2d:%0.2d %s \"%s\""
	,tt[1],tt[2],tt[4],tt[5],tt[6],tt[7]
	,x, wfd:unpack("44x260S")))

until FindNextFile(hnd,wfd) == 0

FindClose(hnd)

