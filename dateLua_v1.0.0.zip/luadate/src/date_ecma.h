/**********************************************************
* Copyright (C) 2005, by Jas Latrix (jastejada@yahoo.com) * 
* All Rights Deserved.                                    *
* use this code at your own risk!.                        *
* cigarette smoking is dangerous to your health.          *
**********************************************************/
#ifndef __ECMA_DATE_AND_TIME_CALC_H__
#define __ECMA_DATE_AND_TIME_CALC_H__
#include <math.h>
#include <string.h>
#ifndef DATEVAL
/* typedef __int64 dateval; */
typedef double dateval;
#endif
/* HELPER */
#ifndef AMID
#	define AMID(c,x,y)		(((x)<=(c))&&((c)<=(y)))
#endif
#ifndef ISUPPER
#	define	ISUPPER(c)		(AMID(c,/*A*/65,/*Z*/90))
#endif
#ifndef ISDIGIT
#	define	ISDIGIT(c)		(AMID(c,/*0*/48,/*9*/57))
#endif
#ifndef ISLOWER
#	define	ISLOWER(c)		(AMID(c,/*a*/97,/*z*/122))
#endif
#ifndef ISALPHA
#	define	ISALPHA(c)		(ISUPPER(c)||ISLOWER(c))
#endif
#ifndef TOLOWER
#	define	TOLOWER(c)		(ISUPPER(c)?((c)+32):(c))
#endif
/******
 *	THIS CODE IS BASED ON JAVASCRIPT DATE & TIME MANIPULATION (DATE OBJECT)
 *	IMPLEMENTATION OF ECMA-262 http://www.mozilla.org/js
 *
 *	15.9.1.1 TIME RANGE
 *	Time is measured in ECMAScript in milliseconds since 01 January, 1970 UTC. Leap seconds are ignored. It
 *	is assumed that there are exactly 86,400,000 milliseconds per day. ECMAScript number values can represent
 *	all integers from iMin = -9,007,199,254,740,991 to iMax = 9,007,199,254,740,991; this range suffices to
 *	measure times to millisecond precision for any instant that is within approximately 285,616 years, either
 *	forward or backward, from 01 January, 1970 UTC.
 *	The actual range of times supported by ECMAScript Date objects is slightly smaller: exactly �100,000,000
 *	days to 100,000,000 days measured relative to midnight at the beginning of 01 January, 1970 UTC. This gives
 *	a range of 8,640,000,000,000,000 milliseconds to either side of 01 January, 1970 UTC. This span easily
 *	covers all of recorded human history and a fair amount of unrecorded human history.
 *	The exact moment of midnight at the beginning of 01 January, 1970 UTC is represented by the value +0.
 ******
 *	Constants
 */
/* Work around msvc double optimization bug by making these runtime values; if
 * they're available at compile time, msvc optimizes division by them by
 * computing the reciprocal and multiplying instead of dividing - this loses
 * when the reciprocal isn't representable in a double. STUPID!M$.
 */
static dateval HoursPerDay	= 24.0;
static dateval MinutesPerHour = 60.0;
static dateval SecondsPerMinute=	60.0;
static dateval MinutesPerDay	= 1440.0/*(HoursPerDay * MinutesPerHour)*/;
static dateval SecondsPerDay	= 86400.0/*(MinutesPerDay * SecondsPerMinute)*/;
static dateval SecondsPerHour = 3600.0/*(MinutesPerHour * SecondsPerMinute)*/;
static dateval msPerSecond = 1000;
static dateval msPerDay = 86400000.0;/*24*60*60*1000*/
static dateval msPerHour = 3600000.0;
static dateval msPerMinute = 60000.0;
static dateval HalfTimeDomain = 8.64e15;
/******
 *	15.9.1.2 DAY NUMBER AND TIME WITHIN DAY
 *	A given time value t belongs to day number
 *		Day(t) = floor(t / msPerDay)
 */
#define Day(t)	floor((t) / msPerDay)
/******
 *	The remainder is called the time within the day:
 */
dateval TimeWithinDay(dateval t);
/******
 *	15.9.1.3 YEAR NUMBER
 *	ECMAScript uses an extrapolated Gregorian system to map a day number to a year number and to determine
 *	the month and date within that year.In this system, leap years are precisely those which are (divisible by 4)
 *	and ((not divisible by 100) or (divisible by 400)). The number of days in year number y is therefore defined by
 *	DaysInYear(y)	= 365 if (y modulo 4) != 0
 *					= 366 if (y modulo 4) = 0 and (y modulo 100) != 0
 *					= 365 if (y modulo 100) = 0 and (y modulo 400) != 0
 */
#define DaysInYear(y)   ((y) % 4 == 0 && ((y) % 100 || ((y) % 400 == 0))  ? 366 : 365)
/******
 *	Of course all non-leap years have 365 days with the usual number of days per month and leap years have an
 *	extra day in February. The day number of the first day of year y is given by:
 *	DayFromYear(y) = 365�(y-1970) + floor((y-1969)/4) - floor((y-1901)/100) + floor((y-1601)/400)
 *
 *  math here has to be f.p, because we need
 *  floor((1968 - 1969) / 4) == -1
 */
#define DayFromYear(y)  (365 * ((y)-1970) + floor(((y)-1969)/4.0)	\
			 - floor(((y)-1901)/100.0) + floor(((y)-1601)/400.0))
/******
 *	The time value of the start of a year is:
 */
#define TimeFromYear(y) (DayFromYear(y) * msPerDay)
/******
 *	A time value determines a year by:
 *	YearFromTime(t) = the largest integer y (closest to positive infinity) such that TimeFromYear(y) <= t
 */
int YearFromTime(dateval t);
/******
 *	The leap-year function is 1 for a time within a leap year and otherwise is zero:
 *	InLeapYear(t)	= 0 if DaysInYear(YearFromTime(t)) = 365
 *					= 1 if DaysInYear(YearFromTime(t)) = 366
 */
#define InLeapYear(t)   (int) (DaysInYear(YearFromTime(t)) == 366)
/*** /
 *	15.9.1.4 MONTH NUMBER
 *	Months are identified by an integer in the range 0 to 11, inclusive. The mapping MonthFromTime(t) from a
 *	time value t to a month number is defined by:
 *	MonthFromTime(t)
 *	= 0 if 0 � DayWithinYear(t) < 31
 *	= 1 if 31 <= DayWithinYear (t) < 59+InLeapYear(t)
 *	= 2 if 59+InLeapYear(t) <= DayWithinYear (t) < 90+InLeapYear(t)
 *	= 3 if 90+InLeapYear(t) <= DayWithinYear (t) < 120+InLeapYear(t)
 *	= 4 if 120+InLeapYear(t) <= DayWithinYear (t) < 151+InLeapYear(t)
 *	= 5 if 151+InLeapYear(t) <= DayWithinYear (t) < 181+InLeapYear(t)
 *	= 6 if 181+InLeapYear(t) <= DayWithinYear (t) < 212+InLeapYear(t)
 *	= 7 if 212+InLeapYear(t) <= DayWithinYear (t) < 243+InLeapYear(t)
 *	= 8 if 243+InLeapYear(t) <= DayWithinYear (t) < 273+InLeapYear(t)
 *	= 9 if 273+InLeapYear(t) <= DayWithinYear (t) < 304+InLeapYear(t)
 *	= 10 if 304+InLeapYear(t) <= DayWithinYear (t) < 334+InLeapYear(t)
 *	= 11 if 334+InLeapYear(t) <= DayWithinYear (t) < 365+InLeapYear(t)
 *	where
 *	DayWithinYear(t)= Day(t)-DayFromYear(YearFromTime(t))
 *	A month value of 0 specifies January; 1 specifies February; 2 specifies March; 3 specifies April; 4 specifies
 *	May; 5 specifies June; 6 specifies July; 7 specifies August; 8 specifies September; 9 specifies October; 10
 *	specifies November; and 11 specifies December. Note that MonthFromTime(0) = 0, corresponding to
 *	Thursday, 01 January, 1970.
 */
#define DayWithinYear(t, year) ((int) (Day(t) - DayFromYear(year)))
int MonthFromTime(dateval t);
/******
 *	15.9.1.5 DATE NUMBER
 *	A date number is identified by an integer in the range 1 through 31, inclusive. The mapping DateFromTime(t)
 *	from a time value t to a month number is defined by:
 *	DateFromTime(t)
 *	= DayWithinYear(t)+1 if MonthFromTime(t)=0
 *	= DayWithinYear(t)-30 if MonthFromTime(t)=1
 *	= DayWithinYear(t)-58-InLeapYear(t) if MonthFromTime(t)=2
 *	= DayWithinYear(t)-89-InLeapYear(t) if MonthFromTime(t)=3
 *	= DayWithinYear(t)-119-InLeapYear(t) if MonthFromTime(t)=4
 *	= DayWithinYear(t)-150-InLeapYear(t) if MonthFromTime(t)=5
 *	= DayWithinYear(t)-180-InLeapYear(t) if MonthFromTime(t)=6
 *	= DayWithinYear(t)-211-InLeapYear(t) if MonthFromTime(t)=7
 *	= DayWithinYear(t)-242-InLeapYear(t) if MonthFromTime(t)=8
 *	= DayWithinYear(t)-272-InLeapYear(t) if MonthFromTime(t)=9
 *	= DayWithinYear(t)-303-InLeapYear(t) if MonthFromTime(t)=10
 *	= DayWithinYear(t)-333-InLeapYear(t) if MonthFromTime(t)=11
 */
int DateFromTime(dateval t);
/******
 *	15.9.1.6 WEEK DAY
 *	The week day for a particular time value t is defined as
 *		WeekDay(t) = (Day(t) + 4) modulo 7
 *	A weekday value of 0 specifies Sunday; 1 specifies Monday; 2 specifies Tuesday; 3 specifies Wednesday;
 *	4 specifies Thursday; 5 specifies Friday; and 6 specifies Saturday. Note that WeekDay(0) = 4, corresponding
 *	to Thursday, 01 January, 1970.
 */
int WeekDay(dateval t);
/******
 *	15.9.1.10 HOURS, MINUTES, SECOND, AND MILLISECONDS
 *	The following functions are useful in decomposing time values:
 *	HourFromTime(t) = floor(t / msPerHour) modulo HoursPerDay
 *	MinFromTime(t) = floor(t / msPerMinute) modulo MinutesPerHour
 *	SecFromTime(t) = floor(t / msPerSecond) modulo SecondsPerMinute
 *	msFromTime(t) = t modulo msPerSecond
 */
int HourFromTime(dateval t);
int MinFromTime(dateval t);
int SecFromTime(dateval t);
int msFromTime(dateval t);
/******
 *	15.9.1.11 MAKETIME(HOUR, MIN, SEC, MS)
 *	The operator MakeTime calculates a number of milliseconds from its four arguments, which must be
 *	ECMAScript number values. This operator functions as follows:
 *	1. If hour is not finite or min is not finite or sec is not finite or ms is not finite, return NaN.
 *	2. Call ToInteger(hour).
 *	3. Call ToInteger(min).
 *	4. Call ToInteger(sec).
 *	5. Call ToInteger(ms).
 *	6. Compute Result(2) * msPerHour + Result(3) * msPerMinute + Result(4) * msPerSecond + Result(5),
 *	performing the arithmetic according to IEEE 754 rules (that is, as if using the ECMAScript operators *
 *	and +).
 *	7. Return Result(6).
 */
#define MakeTime(hour, min, sec, ms) \
(((hour * MinutesPerHour + min) * SecondsPerMinute + sec) * msPerSecond + ms)
/******
 *	15.9.1.12 MAKEDAY(YEAR, MONTH, DATE)
 *	The operator MakeDay calculates a number of days from its three arguments, which must be ECMAScript
 *	number values. This operator functions as follows:
 *	1. If year is not finite or month is not finite or date is not finite, return NaN.
 *	2. Call ToInteger(year).
 *	3. Call ToInteger(month).
 *	4. Call ToInteger(date).
 *	5. Compute Result(2) + floor(Result(3)/12).
 *	6. Compute Result(3) modulo 12.
 *	7. Find a value t such that YearFromTime(t)==Result(5) and MonthFromTime(t)==Result(6) and
 *	DateFromTime(t)==1; but if this is not possible (because some argument is out of range), return NaN.
 *	8. Compute Day(Result(7)) + Result(4) - 1.
 *	9. Return Result(8).
 *
 * The following array contains the day of year for the first day of
 * each month, where index 0 is January, and day 0 is January 1.
 */
dateval MakeDay(dateval year, dateval month, dateval date);
/******
 *	15.9.1.13 MAKEDATE(DAY, TIME)
 *	ECMAScript number values. This operator functions as follows:
 *	If day is not finite or time is not finite, return NaN.
 *	2. Compute day � msPerDay + time.
 *	3. Return Result(2).
 */
#define MakeDate(day, time) (day * msPerDay + time)
/******
 *	15.9.1.14 TIMECLIP(TIME)
 *	The operator TimeClip calculates a number of milliseconds from its argument, which must be an ECMAScript
 *	number value. This operator functions as follows:
 *	1. If time is not finite, return NaN.
 *	2. If abs(Result(1)) > 8.64e15 (that is, 8.64 � 10 15 ), return NaN.
 *	3. Return an implementation dependent choice of either ToInteger(Result(2)) or ToInteger(Result(2)) + (+0).
 *	(Adding a positive zero converts -0 to +0.)
 */
#define IN_TIME_RANGE(d) (!((d < 0 ? -d : d) > HalfTimeDomain))
/* Change!!!
#define TIMECLIP(d) ((JSDOUBLE_IS_FINITE(d) \
		      && IN_TIME_RANGE(d) \
		     ? js_DoubleToInteger(d + (+0.)) : 0.0)*/
/*#define TIMECLIP(d) (IN_TIME_RANGE(d)?Float2Int((d)+(+0.)):0.0)*/
dateval Float2Int(dateval d);
int TimeClip(dateval* pd);
/******
 *	find UTC time from given date... no 1900 correction!
 */
dateval msecFromDate(dateval year, dateval mon, dateval mday, dateval hour,
		  dateval min, dateval sec, dateval msec);
/******
 *	DATE STRING PARSE (Modified Accept Timezone "LOC" meaning locale)
 *	returns 
 *	1	ok
 *	-1	no timezone prase
 *	0	error
 */
/* helper for date_parse */
int regionMatches(const char* s1, int s1off, const char* s2, int s2off,
				   int count, int ignoreCase);
int parseString(const char *s, dateval *result, int *plocal);
/* date value macros */
#define	dv_year(dv)	YearFromTime(dv)
#define	dv_month(dv)MonthFromTime(dv)
#define	dv_mday(dv)	DateFromTime(dv)
#define	dv_hour(dv)	HourFromTime(dv)
#define	dv_min(dv)	MinFromTime(dv)
#define	dv_sec(dv)	SecFromTime(dv)
#define	dv_msec(dv)	msFromTime(dv)
#define	dv_wday(dv)	WeekDay(dv)
#define	dv_yday(dv)	DayWithinYear((dv),dv_year(dv))
#define	dv_to_timet(dv)		((time_t)dv_span_sec(dv))
#define	dv_from_timet(tt)	((dateval)dc_sec_to_msec(((dateval)tt)))
#define	dv_max_val HalfTimeDomain
#define	dv_min_val -HalfTimeDomain
#define	dv_span_year(dv)	((dv)/(msPerDay*365.2425))
#define	dv_span_month(dv)	((dv)/(msPerDay*30.43685))
#define	dv_span_hour(dv)	((dv)/msPerHour)
#define	dv_span_min(dv)		((dv)/msPerMinute)
#define	dv_span_sec(dv)		((dv)/msPerSecond)
#define	dv_span_msec(dv)	(dv)
#define	dv_span_day(dv)		((dv)/86400000.0)
/* date calculation helper */
#define dc_sec_to_min(sec)	((sec)/60)
#define dc_sec_to_msec(sec)	((sec)*1000)
#define dc_min_to_sec(min)	((min)*60)
#define dc_min_to_hour(min)	((min)/60)
#define dc_min_to_msec(min)	((min)*60*1000)

#define dc_is_leap_year(yr) \
   (yr != 0 && ((((yr & 0x3) == 0) &&  \
		   ((yr - ((yr/100) * 100)) != 0)) || \
		  (yr - ((yr/400) * 400)) == 0))
/* HELPER */
#define dc_12hr(hr)		((hr)>12?(hr)%12:((hr)==0?12:(hr)))
/* hour is AM or PM*/
#define dc_xmeridian(hr)				((hr)>11?"PM":"AM")
/* map 510 minutes to 0830 hours */
#define dc_min_to_100hr(mn)		((dc_min_to_hour(mn) * 100) + ((mn) % 60))
/* bias = loc - utc */
#define dc_get_bias(loc,utc)	((time_t)(((time_t)(loc)) - ((time_t)(utc))))
/* utc = loc - bias */
#define dc_get_utc(bias,loc)	(((dateval)(loc)) - ((dateval)dc_sec_to_msec(bias)))
/* loc = utc + bias */
#define dc_get_loc(bias,utc)	(((dateval)(utc)) + ((dateval)dc_sec_to_msec(bias)))


#endif /* __ECMA_DATE_AND_TIME_CALC_H__ */