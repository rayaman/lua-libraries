/**********************************************************
* Copyright (C) 2005, by Jas Latrix (jastejada@yahoo.com) * 
* All Rights Deserved.                                    *
* use this code at your own risk!.                        *
* keep out of reach of children.                          *
**********************************************************/
/*** LOCAL TIME AND DATE (SYSTEM DEPENDENT) ***/
#include "date_ecma.h"
#include "date_local.h"
#include <time.h>
#define USE_ANSIC
#define TIME_T_MAX_VALUE			((2145859200.0-24*60*60)*1000)
#define TIME_T_MIN_VALUE			(24*60*60*1000)
#define dv_in_timet_safe_range(d)	AMID(d,TIME_T_MIN_VALUE,TIME_T_MAX_VALUE)
#define dv_check_timet(dv)			dv_to_timet( \
				dv_in_timet_safe_range(dv)?dv:dv_to_equiv_time(dv) \
				)
int equiv_times[/*wday*/][2/*leapyear?*/] = {
/*Sunday, January 01 1978 12:00:00 AM UTC
00 Sunday, January 01 1984 12:00:00 AM UTC	 LEAP*/
		{1978,1984},
/*Monday, January 01 1973 12:00:00 AM UTC
01Monday, January 01 1996 12:00:00 AM UTC	 LEAP*/
		{1973,1996},
/*Tuesday, January 01 1974 12:00:00 AM UTC
02Tuesday, January 01 1980 12:00:00 AM UTC	 LEAP*/
		{1974,1980},
/*Wednesday, January 01 1975 12:00:00 AM UTC
03Wednesday, January 01 1992 12:00:00 AM UTC	 LEAP*/
		{1975,1992},
/*Thursday, January 01 1970 12:00:00 AM UTC
04Thursday, January 01 1976 12:00:00 AM UTC	 LEAP*/
		{1970,1976},
/*Friday, January 01 1971 12:00:00 AM UTC
05Friday, January 01 1988 12:00:00 AM UTC	 LEAP*/
		{1971,1988},
/*Saturday, January 01 1977 12:00:00 AM UTC
06Saturday, January 01 1972 12:00:00 AM UTC	 LEAP*/
		{1977,1972},
	};

#ifdef _WIN32
	#include <windows.h>
	#include <stdio.h>
	#define WIN_MINDV	(-11360476800000.0 + 24*60*60*1000)/*Saturday, January 02 1610 12:00:00 AM UTC*/
	#define WIN_MAXDV	HalfTimeDomain
	#define dv_in_win_range(d)	AMID(d,WIN_MINDV,WIN_MAXDV)

	#define EPOCH_BIAS  116444736000000000i64
	#define dv_to_win(d)	(((__int64)d)*10000i64+EPOCH_BIAS)
	#define dv_from_win(f)	(dateval)((((__int64)f) - EPOCH_BIAS)/10000i64)
	#define FT_PFILETIME(f)	(&f.ft_struct)
	typedef union {
			unsigned __int64 dv;
			FILETIME ft;
			} FT;
	int TRC(char *pszfmt, ...){
		char chbuf[1024];
		va_list argList = NULL;
		va_start(argList, pszfmt);
		vsprintf(chbuf,pszfmt,argList);
		va_end(argList);
		return MessageBox(0,(char *)chbuf,0,0);
	}
#endif


int lt_now(dateval * pdv) {
#ifdef USE_ANSIC
	time_t sec = time(NULL);
	*pdv = dv_from_timet(sec);
	return (sec!=(time_t)-1);
#elif defined(_WIN32)
/*	Win9x gets confused at midnight
	http://support.microsoft.com/default.aspx?scid=KB;en-us;q224423
	So if the low part (precision <8mins) is 0 then we get the time
	again. */
	FT ftu;
    GetSystemTimeAsFileTime(&ftu.ft);
	if(!ftu.ft.dwLowDateTime){
		FT ftm;
        GetSystemTimeAsFileTime(&ftm.ft);
        ftu.ft.dwHighDateTime = ftm.ft.dwHighDateTime;
	}
	*pdv = dv_from_win(ftu);
	return 1;
#else
	#error ERROR: Add other OS codes!
#endif
}



#define dc_tm_to_timet(ptm)		((time_t)dv_span_sec(dv_from_tm(ptm)))
dateval dv_from_tm(struct tm * ptm){
	return msecFromDate(ptm->tm_year+1900,ptm->tm_mon,ptm->tm_mday,ptm->tm_hour,ptm->tm_min,ptm->tm_sec,0);
}
struct tm * dv_to_tm(dateval dv, struct tm * ptm, int isdst){
	ptm->tm_hour = (int)dv_hour(dv);
	ptm->tm_mday = (int)dv_mday(dv);
	ptm->tm_min = (int)dv_min(dv);
	ptm->tm_mon = (int)dv_month(dv);
	ptm->tm_sec = (int)dv_sec(dv);
	ptm->tm_wday = (int)dv_wday(dv);
	ptm->tm_yday = (int)dv_yday(dv);
	ptm->tm_year = (int)dv_year(dv);
	ptm->tm_year -= 1900;
	ptm->tm_isdst = isdst;
	return ptm;
}
dateval dv_to_equiv_time(dateval dv){
	/* break it down! */
	int yr = dv_year(dv);
	int mo = dv_month(dv);
	int dm = dv_mday(dv);
	int hr = dv_hour(dv);
	int mn = dv_min(dv);
	int sc = dv_sec(dv);
	int ms = dv_msec(dv);
	int wd,lp;
	/* change the month to jan, date to 1 (first day of year) */
	dv = msecFromDate(yr,0,1,hr,mn,sc,ms);
	/* get equivalent year */
	lp = dc_is_leap_year(yr);
	wd = dv_wday(dv);
	yr = equiv_times[wd][lp];
	/* get equivalent year */
	dv = msecFromDate(yr,mo,dm,hr,mn,sc,ms);
	return dv;
}


int lt_loc2utc (const dateval dloc, dateval* pdutc) {
#ifdef USE_ANSIC
	time_t bias = 0;
	time_t tloc = 0;
	time_t tutc = 0;
	struct tm tmloc;
	memset(&tmloc,0,sizeof(tmloc));
	/** /TRC_DV(dutc,"lt_loc2utc");/**/
	tloc = dv_check_timet(dloc);
	tutc = mktime(dv_to_tm(dv_from_timet(tloc),&tmloc,-1));
	if(tutc!=-1){
		bias = dc_get_bias(tloc,tutc);
		*pdutc = dc_get_utc(bias,dloc);
		return 1;
	}
#elif defined(_WIN32)
	FT ftu, ftl;
	ftl.dv = dv_to_win(dloc);
	if(LocalFileTimeToFileTime(&ftl.ft_struct,&ftu.ft_struct)){
		*pdutc = dv_from_win(ftu);
		return 1;
	}
#else
	#error ERROR: Add other OS codes!
#endif
	return 0;
}
int lt_utc2loc (const dateval dutc, dateval* pdloc, int *pbias){
#ifdef USE_ANSIC
	time_t bias = 0;
	time_t tloc = 0;
	time_t tutc = 0;
	struct tm *ptmloc = 0;
	/** /TRC_DV(dutc,"lt_utc2loc");/**/
	tutc = dv_check_timet(dutc);
	ptmloc = localtime(&tutc);
	if(ptmloc){
		tloc = dv_to_timet(dv_from_tm(ptmloc));
		bias = dc_get_bias(tloc,tutc);
		*pdloc = dc_get_loc(bias,dutc);
		if(pbias){/* check local time bias */
			*pbias = (int)(dc_sec_to_min(bias));
		}
		return 1;
	}
#elif defined(_WIN32)
	FT ftu, ftl;
	ftu.dv = dv_to_win(dutc);
	if(FileTimeToLocalFileTime(ftu.ft,ftl.ft)){
		*pdloc = dv_from_win(ftl);
		if(pbias){/* check local time bias */
			*pbias = (int)((*pdloc-dutc)/60000);
		}
		return 1;
	}
#else
	#error ERROR: Add other OS codes!
#endif
	return 0;
}
int lt_isdst(const dateval dutc){
	time_t tutc = dv_check_timet(dutc);
	struct tm *tmp = localtime(&tutc);
	return tmp?(tmp->tm_isdst):-1;; 
}

int lt_get_month_name(char *pszBuffer, size_t max, int idx, int abbv){
	struct tm tms;
	memset(&tms,0,sizeof(struct tm));
	tms.tm_mon = idx;
	pszBuffer[0] = 0;
	return (strftime(pszBuffer,max,abbv?"%B":"%b",&tms) && pszBuffer[0]); 
}

int lt_get_day_name(char *pszBuffer, size_t max, int idx, int abbv){
	struct tm tms;
	memset(&tms,0,sizeof(struct tm));
	tms.tm_wday = idx;
	pszBuffer[0] = 0;
	return (strftime(pszBuffer,max,abbv?"%A":"%a",&tms) && pszBuffer[0]);
}
int lt_tzstr(dateval dutc, char * pchbuf, size_t szbuf){
#ifdef USE_ANSIC
	struct tm *ptm = 0;
	time_t tutc = dv_check_timet(dutc);
	ptm = localtime(&tutc);
	pchbuf[0] = 0;
	return (ptm && strftime(pchbuf, szbuf, "%Z", ptm) && pchbuf[0]);
#elif defined(_WIN32)
	TIME_ZONE_INFORMATION tzi;
	memset(&tzi,0,sizeof(TIME_ZONE_INFORMATION));	
	return (0xFFFFFFFF!=GetTimeZoneInformation(&tzi)) && 
		WideCharToMultiByte(CP_ACP,0,
		(LPCWSTR)(lt_isdst(dutc)?tzi.DaylightName:tzi.StandardName),
		(int)-1,(LPSTR)pchbuf,(int)szbuf,NULL, NULL);
#else
	#error ERROR: Add other OS codes!
#endif
}

int lt_get_datetime_str(dateval dv, char *pszBuffer, size_t max, int code){
	char chFmt[] = {'%','C',0};
	struct tm tms;
	chFmt[1] = (char)code;
	pszBuffer[0] = 0;
	memset(&tms,0,sizeof(tms));
	dv_to_tm(dv,&tms,-1);
	return (strftime(pszBuffer,max,chFmt,&tms) && pszBuffer[0]); 
}